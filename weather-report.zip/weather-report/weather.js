$(document).ready(function(){

	$("#submitCity").click(function(){
		return getWeather();
	});
});

function getWeather(){
	var city = $("#city").val();

	if(city != ''){
		$.ajax({
			url: 'http://api.openweathermap.org/data/2.5/weather?q=' + city + "&units=metric" + 
			"&APPID=52827ce67cdeeaaf0c60c4b244f1bf10", 
			type: "GET",
			dataType: "jsonp",
			success: function(data){

				var widget = showResults(data);
				
				$("#showWeather").html(widget);
				$("#city").val('');
			}
		});
	}
	else
	{
		$("#error").html("<div class='alert alert-danger' id='errorCity'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>City field cannot be empty</div>");
	}
}


function showResults(data){
		return'<div class="weather-left"> ' +
				'<div class="weather-left-text"> '+  
					 '<h1>' +data.name + ',' +data.sys.country + '</h1></br></br> ' +
					'<h4>Latitude: '+data.coord.lon+ '</h4>' +
					'<h4>Longitude: '+data.coord.lat+ '</h4>' +
					'<h4> Weather:  '  +data.weather[0].main+  '</h4>'+
					'<h4> Pressure:  '  +data.main.pressure+  'hPa</h4>'+
					'<h4> Humidity:  '  +data.main.humidity+  '%</h4>'+
					'<h4> Wind Direction:  '  +data.wind.deg+  'deg</h4>'+
					
					"</div>" +
			'</div>'+
			
			 '<div class="weather-right"> ' +
				'<ul>'+
					'<li>' +
						'<figure class="icons">'+
							'<canvas id="partly-cloudy-day" width="60" height="60"></canvas>'+
						'</figure>'+
						'<h3>'+data.main.temp+' °C</h3>'+
						'<div class="clear"></div>'+
					'</li>'+
					'<li>'+
						 '<figure class="icons">'+
							'<canvas id="clear-day" width="40" height="40"></canvas>'+
						'</figure>'+
						'<div class="weather-text">'+
							'<h4>TEMP </h4>'+
							'<h5>MIN ' +data.main.temp_min+'°C</h5>'+
							'<h5>MAX ' +data.main.temp_max+'°C</h5>'+
						'</div>'+
						'<div class="clear"></div>'+
					'</li>'+
					'<li>'+
						'<figure class="icons">'+
							'<canvas id="wind" width="40" height="40"></canvas>'+
						'</figure>'+
						'<div class="weather-text">'+
						    '<h4>Wind Speed</h4>'+
							'<h4>'+data.wind.speed+' m/s</h4>'+
						'</div>'+
						'<div class="clear"></div>'+
					'</li>'+
					'<li>'+
						'<figure class="icons">'+
							'<canvas id="cloudy" width="40" height="40"></canvas>'+
						'</figure>'+
						'<div class="weather-text">'+
							'<h4>Cloud</h4>'+
							'<h5>'+data.clouds.all+'%</h5>'+
						'</div>'+
						'<div class="clear"></div>'+
					'</li>'+
				'</ul>'+
				'<div>'+
				 '<script>'+
					 'var icons = new Skycons({"color": "#fff"}),'+
						 ' list  = ['+
						'	"partly-cloudy-day"'+
						'  ],'+
						 ' i;'+

					'  for(i = list.length; i--; )'+
						'icons.set(list[i], list[i]);'+
					 ' icons.play();'+
				'</script>'+
				'<script>'+
					 'var icons = new Skycons({"color": "#fff"}),'+
						  'list  = ['+
							'"clear-night","partly-cloudy-night", "cloudy", "clear-day", "sleet", "snow", "wind","fog"'+
						 ' ],'+
						  'i;'+

					  'for(i = list.length; i--; )'+
						'icons.set(list[i], list[i]);'+
					 ' icons.play();'+
				'</script> '+
			' </div>';
}